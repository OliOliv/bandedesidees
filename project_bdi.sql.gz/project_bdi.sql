-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 10, 2019 at 11:29 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olioliv_bdi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `idUser` smallint(3) NOT NULL,
  `user` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auteurs`
--

CREATE TABLE `auteurs` (
  `idAuteur` int(6) NOT NULL,
  `nom_auteur` varchar(40) DEFAULT NULL,
  `prenom_auteur` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auteurs`
--

INSERT INTO `auteurs` (`idAuteur`, `nom_auteur`, `prenom_auteur`) VALUES
(1, 'Lemire', 'Jeff '),
(2, 'Kamatani', 'Yuhki'),
(3, 'Texier', 'Olivier'),
(4, 'Malherbe', 'Arnaud'),
(5, 'Bravo', 'Emile'),
(6, 'Koivunen ', 'Peppe '),
(7, 'Rokudenashiko ', ''),
(8, 'Gipi', ''),
(9, 'El Hamouri ', 'Aniss'),
(10, 'Clowes', 'Daniel'),
(11, 'Ichikawa', 'Raku '),
(12, 'Hickman', 'Jonathan'),
(13, 'Grennvall', 'Asa'),
(14, 'Goblet', 'Dominique'),
(15, 'Dillies', 'Renaud'),
(16, 'Horrocks', 'Dylan'),
(17, 'Furuya', 'Usumaru'),
(18, 'Dupont', 'Jean-Michel'),
(19, 'Evans', 'Brecht'),
(20, 'Kichiku', 'Neko'),
(21, 'Yukimura', 'Makoto'),
(22, 'Mori', 'Kaoru'),
(23, 'Yamakawa ', 'Naoki'),
(24, 'Le Corvaisier', 'Jérémy'),
(25, 'Snyder', 'Scott'),
(26, 'Charyn', 'Jérome'),
(27, 'Marchalot', 'Antoine\r\n'),
(28, 'Gleason', 'Emilie'),
(29, 'Bunjevac', 'Nina'),
(30, 'King', 'Tom'),
(31, 'Joor', 'Louise'),
(32, 'Wary', 'Chloé'),
(33, 'Goossens', 'Daniel'),
(34, 'Kon', 'Satoshi'),
(35, 'Brown', 'Chester'),
(36, 'Picault', 'Aude'),
(37, 'Nakamura', 'Atsuhiko'),
(39, 'Ramstein', 'Anne-Margot'),
(40, 'Tebo', ''),
(41, 'Max', ''),
(42, 'Fert', 'Stéphanie');

-- --------------------------------------------------------

--
-- Table structure for table `croquis`
--

CREATE TABLE `croquis` (
  `idCroquis` int(11) NOT NULL,
  `src` varchar(255) DEFAULT NULL,
  `soiree_id` int(11) DEFAULT NULL,
  `auteur` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `croquis`
--

INSERT INTO `croquis` (`idCroquis`, `src`, `soiree_id`, `auteur`) VALUES
(1, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/47571384_2254908397885526_2608536228173185024_o.jpg?_nc_cat=105&_nc_ht=scontent-cdg2-1.xx&oh=6a34d63a479e9ab7c26c997f0a91cf9d&oe=5D6D7122', 40, 'Aymeric Ingret'),
(2, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/47362618_2254908364552196_5393794572276989952_o.jpg?_nc_cat=106&_nc_ht=scontent-cdg2-1.xx&oh=f88f4d43957e9ac1a6e4fecee7c93549&oe=5D727CEA', 40, 'Aymeric Ingret'),
(3, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/47388798_2254908307885535_6260786652151545856_n.jpg?_nc_cat=104&_nc_ht=scontent-cdg2-1.xx&oh=6df5e2a49af61f470f317f799687314b&oe=5D3DA04D', 40, 'Aymeric Ingret'),
(4, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/47396421_2254908297885536_8251086896688529408_o.jpg?_nc_cat=105&_nc_ht=scontent-cdg2-1.xx&oh=c753e8dab7d4e112952ac3abdc5f1a24&oe=5D6BED4E', 40, 'Aymeric Ingret'),
(5, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49854796_2315603188482713_1871530599072661504_n.jpg?_nc_cat=109&_nc_ht=scontent-cdg2-1.xx&oh=d29283edf4f352f854a2f5771daa500f&oe=5CF987C3\r\n', 41, 'Troan'),
(6, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/50183082_2315603045149394_100952884169932800_n.jpg?_nc_cat=106&_nc_ht=scontent-cdg2-1.xx&oh=0359ad2621d6d07abdd44e7dead00c7d&oe=5D77E687', 41, 'Troan'),
(7, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49344615_2315603015149397_5387782631674871808_n.jpg?_nc_cat=103&_nc_ht=scontent-cdg2-1.xx&oh=e05aa9bde960fc7893443414217b6703&oe=5D3AE510', 41, 'Troan'),
(8, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/50340682_2315603531816012_3482347616602161152_n.jpg?_nc_cat=107&_nc_ht=scontent-cdg2-1.xx&oh=8209959c4dbe99368fb33c1a4e29e8d2&oe=5D2FFB00', 41, 'Aymeric'),
(9, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/50078623_2315603441816021_7940073522917801984_o.jpg?_nc_cat=109&_nc_ht=scontent-cdg2-1.xx&oh=f30a1ea1ed4871560f028d2e392f4b49&oe=5CFE32C3', 41, 'Aymeric'),
(10, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49948821_2315602981816067_2026661016758124544_n.jpg?_nc_cat=101&_nc_ht=scontent-cdg2-1.xx&oh=2dc61fe9ac1b094c119b63fb3d626684&oe=5D6925F4', 41, 'Aymeric'),
(11, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49787328_2315603318482700_8680716559821307904_n.jpg?_nc_cat=104&_nc_ht=scontent-cdg2-1.xx&oh=be26edd91b19f20760acfcd71e14c9c9&oe=5CFAF2E6', 41, 'Aymeric'),
(12, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49899804_2315603545149344_4878544529940021248_n.jpg?_nc_cat=101&_nc_ht=scontent-cdg2-1.xx&oh=e143028c01133ac358ece6d44548ed5b&oe=5CF52C07', 41, 'Aymeric'),
(13, 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/49845001_2315603591816006_239056728644124672_o.jpg?_nc_cat=107&_nc_ht=scontent-cdg2-1.xx&oh=f96fb60ba266d44a7996eaf21189922b&oe=5CFC4A45', 41, 'Aymeric');

-- --------------------------------------------------------

--
-- Table structure for table `dessinateurs`
--

CREATE TABLE `dessinateurs` (
  `idDessinateur` int(6) NOT NULL,
  `nom_dessinateur` varchar(40) DEFAULT NULL,
  `prenom_dessinateur` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dessinateurs`
--

INSERT INTO `dessinateurs` (`idDessinateur`, `nom_dessinateur`, `prenom_dessinateur`) VALUES
(1, 'Sorrentino', 'Andrea'),
(2, 'Pfieffer', 'Kai'),
(3, 'Mezzo', ''),
(4, 'TogaQ', ''),
(5, 'Asaki', 'Masashi'),
(6, 'Sakuraichi', 'Bargain');

-- --------------------------------------------------------

--
-- Table structure for table `editeurs`
--

CREATE TABLE `editeurs` (
  `idEditeur` int(6) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `site` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `editeurs`
--

INSERT INTO `editeurs` (`idEditeur`, `nom`, `site`) VALUES
(1, 'Les Requins Marteaux', 'http://lesrequinsmarteaux.com/livres'),
(2, 'Urban', 'https://www.urban-comics.com/'),
(3, 'Dargaud', 'http://www.dargaud.com/'),
(4, 'Akata', 'http://www.akata.fr/'),
(5, 'Dupuis', 'https://www.dupuis.com/catalogue/FR/accueil.html'),
(6, 'Rackam', 'https://www.editions-rackham.com/'),
(7, 'Futuropolis', 'http://www.futuropolis.fr/'),
(8, 'Vide Cocagne', 'https://videcocagne.fr/'),
(9, 'Cornelius', 'cornelius.fr'),
(10, 'L\'agrume', 'http://lagrume.org/'),
(11, 'Actes Sud', 'https://www.actes-sud.fr'),
(12, 'Casterman', 'https://www.casterman.com'),
(13, 'IMHO', 'https://www.imho.fr'),
(14, 'Glénat', 'https://www.glenat.com'),
(15, 'Les Enfants Rouges', 'http://enfantsrouges.com/'),
(16, 'Le Lombard', 'http://www.lelombard.com/'),
(17, 'Arbitraire', 'http://www.arbitraire.fr/'),
(18, 'Kurokawa', 'https://www.kurokawa.fr/'),
(19, 'Ki-oon', 'http://www.ki-oon.com/'),
(20, 'Panini', 'http://www.paninicomics.fr/web/guest/manga/news'),
(21, 'Taifu', 'http://www.taifu-comics.com/'),
(22, 'Misma', 'https://www.misma.fr'),
(23, 'Atrabile', 'http://atrabile.org'),
(24, 'Delcourt', 'https://www.editions-delcourt.fr/'),
(25, 'Ici-même', 'http://www.icimeme-editions.com/'),
(26, 'Fluide Glacial', 'http://www.fluideglacial.com/'),
(27, 'Flblb', 'https://www.flblb.com/'),
(28, 'L\'Association', 'https://www.lassociation.fr/fr_FR/#!accueil'),
(30, '2024', 'http://www.editions2024.com/'),
(31, 'Michel Lafon', 'http://www.michel-lafon.fr/livres/11-Bandes+dessin%C3%A9es');

-- --------------------------------------------------------

--
-- Table structure for table `intervenants`
--

CREATE TABLE `intervenants` (
  `idIntervenant` int(6) NOT NULL,
  `prenom` varchar(40) NOT NULL,
  `nom` varchar(40) DEFAULT NULL,
  `fb_url` varchar(255) DEFAULT NULL,
  `insta_url` varchar(255) DEFAULT NULL,
  `avatar_src` varchar(255) DEFAULT NULL,
  `activite` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `intervenants`
--

INSERT INTO `intervenants` (`idIntervenant`, `prenom`, `nom`, `fb_url`, `insta_url`, `avatar_src`, `activite`) VALUES
(1, 'Sasha', NULL, NULL, NULL, NULL, 'Libraire'),
(2, 'Charlotte', NULL, NULL, NULL, NULL, 'Libraire'),
(3, 'Côme', NULL, NULL, NULL, NULL, ''),
(4, 'Shyle', NULL, NULL, NULL, NULL, NULL),
(5, 'Côme', NULL, NULL, NULL, NULL, 'Libraire'),
(6, 'Olivia', NULL, NULL, NULL, NULL, 'Développeuse'),
(7, 'Damien ', NULL, NULL, NULL, NULL, 'Libraire'),
(8, 'Tatiana', '', NULL, NULL, NULL, 'Libraire'),
(9, 'Augustin', NULL, NULL, NULL, NULL, NULL),
(10, 'Johan', NULL, NULL, NULL, NULL, NULL),
(11, 'Manon', NULL, NULL, NULL, NULL, NULL),
(12, 'Marie-Charlotte', NULL, NULL, NULL, NULL, NULL),
(13, 'Ludovic', NULL, NULL, NULL, NULL, 'Libraire'),
(14, 'Gwendoline', NULL, NULL, NULL, NULL, 'Libraire'),
(15, 'Sophie', NULL, NULL, NULL, NULL, 'Libraire'),
(16, 'Alex', NULL, NULL, NULL, NULL, 'Libraire'),
(17, 'Sylviane', NULL, NULL, NULL, NULL, 'Libraire'),
(18, 'Mimoun', NULL, NULL, NULL, NULL, 'Libraire'),
(19, 'Pauline', NULL, NULL, NULL, NULL, 'Bibliothécaire'),
(20, 'Pierre', NULL, NULL, NULL, NULL, 'Libraire'),
(21, 'Yannick', NULL, NULL, NULL, NULL, 'Biblio'),
(23, 'Eglantine', NULL, NULL, NULL, NULL, 'Bibliothécaire '),
(24, 'Samuel', 'Polux', NULL, NULL, NULL, 'Libraire'),
(26, 'Anne Teuf', NULL, NULL, NULL, NULL, 'Autrice'),
(27, 'Basile', NULL, NULL, NULL, NULL, 'Éditeur'),
(29, 'Marion', NULL, NULL, NULL, NULL, 'Libraire'),
(30, 'Pierre', NULL, NULL, NULL, NULL, 'Enseignant'),
(31, 'Sébastien', NULL, NULL, NULL, NULL, 'Assistant de production'),
(32, 'Raphaëlle', NULL, NULL, NULL, NULL, 'Libraire'),
(33, ' Christophe', NULL, NULL, NULL, NULL, 'Journaliste'),
(34, 'Gwendoline', NULL, NULL, NULL, NULL, 'Libraire'),
(35, 'Pablo', NULL, NULL, NULL, NULL, 'Libraire'),
(36, 'Julia', NULL, NULL, NULL, NULL, 'Libraire'),
(37, 'Antoine', NULL, NULL, NULL, NULL, 'Libraire'),
(38, 'Anaïs', NULL, NULL, NULL, NULL, 'Libraire'),
(39, 'Clémentine', NULL, NULL, NULL, NULL, 'Libraire'),
(40, 'Léo', NULL, NULL, NULL, NULL, 'Libraire'),
(41, 'Youen', NULL, NULL, NULL, NULL, 'Musicien'),
(42, 'Elsa', NULL, NULL, NULL, NULL, 'Libraire à l\'Arborescence'),
(43, 'Marion', NULL, NULL, NULL, NULL, 'Libraire'),
(44, 'Diego', NULL, NULL, NULL, NULL, NULL),
(45, 'Baptiste', NULL, NULL, NULL, NULL, NULL),
(46, 'Mathilde', NULL, NULL, NULL, NULL, NULL),
(47, 'Margot', NULL, NULL, NULL, NULL, NULL),
(48, 'Raphaelle', '', NULL, NULL, NULL, NULL),
(49, 'Léo', NULL, NULL, NULL, NULL, NULL),
(50, 'Alyssa', NULL, NULL, NULL, NULL, 'Collégienne '),
(51, 'Kelys', NULL, NULL, NULL, NULL, 'Collégienne '),
(52, 'Coralie', NULL, NULL, NULL, NULL, 'Collégienne '),
(53, 'Stéphanie', NULL, NULL, NULL, NULL, 'Collégienne ');

-- --------------------------------------------------------

--
-- Table structure for table `interventions`
--

CREATE TABLE `interventions` (
  `id_intervention` int(6) NOT NULL,
  `id_soiree` int(6) NOT NULL,
  `id_intervenant` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interventions`
--

INSERT INTO `interventions` (`id_intervention`, `id_soiree`, `id_intervenant`) VALUES
(1, 1, 13),
(2, 1, 14),
(3, 1, 15),
(4, 1, 16),
(5, 2, 13),
(6, 2, 17),
(7, 2, 18),
(8, 2, 19),
(9, 4, 20),
(10, 4, 21),
(11, 4, 15),
(12, 4, 23),
(157, 40, 4),
(158, 40, 3),
(159, 40, 2),
(160, 40, 1),
(161, 41, 5),
(162, 41, 6),
(163, 41, 8),
(164, 41, 7),
(165, 42, 9),
(166, 42, 10),
(167, 42, 11),
(168, 42, 12),
(169, 45, 29),
(170, 45, 30),
(171, 45, 32),
(172, 45, 31),
(173, 5, 33),
(174, 5, 34),
(175, 5, 35),
(176, 5, 36),
(177, 46, 37),
(178, 46, 38),
(179, 46, 39),
(180, 46, 40),
(181, 48, 42),
(182, 48, 41),
(183, 48, 2),
(184, 48, 18),
(185, 47, 43),
(186, 47, 44),
(187, 47, 45),
(188, 47, 46),
(189, 52, 47),
(190, 52, 3),
(191, 52, 48),
(192, 52, 49),
(197, 51, 50),
(198, 51, 51),
(199, 51, 52),
(200, 51, 53);

-- --------------------------------------------------------

--
-- Table structure for table `livres`
--

CREATE TABLE `livres` (
  `idLivre` int(6) NOT NULL,
  `titre` varchar(100) NOT NULL,
  `annee_pulication` year(4) NOT NULL,
  `prix` varchar(1000) NOT NULL,
  `edition` int(6) NOT NULL,
  `isbn` varchar(30) NOT NULL,
  `visuel` varchar(255) NOT NULL,
  `soiree_id` int(6) NOT NULL,
  `soiree_id2` int(6) DEFAULT NULL,
  `intervenant_id` int(6) NOT NULL,
  `intervenant_id2` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `livres`
--

INSERT INTO `livres` (`idLivre`, `titre`, `annee_pulication`, `prix`, `edition`, `isbn`, `visuel`, `soiree_id`, `soiree_id2`, `intervenant_id`, `intervenant_id2`) VALUES
(1, 'Nightly News', 2014, '', 2, '', 'https://bdi.dlpdomain.com/album/9782365774062/couv/M385x862/nightly-news.jpg', 1, NULL, 13, NULL),
(2, 'Album de famille', 2014, '', 10, '', 'http://lagrume.org/wp-content/uploads/2014/08/COUV_ALBUM-980x1384.jpg', 1, NULL, 14, NULL),
(3, 'Plus si entente', 2014, '', 11, '', 'https://www.actes-sud.fr/sites/default/files/couv_jpg/9782330030513.jpg', 1, NULL, 15, NULL),
(4, 'Saveur Coco', 2013, '', 3, '', 'https://bdi.dlpdomain.com/album/9782505017912/couv/M320x500/saveur-coco-tome-1-saveur-coco-one-shot.jpg', 1, NULL, 16, NULL),
(5, 'Magic Pen', 2014, '', 12, '', 'https://www.casterman.com/media/cache/couverture_large/casterman_img/Couvertures/9782203081352.jpg', 2, NULL, 13, NULL),
(6, 'Palepoli', 2012, '', 13, '', 'https://www.manga-news.com/public/images/series/palepoli-imho-0.jpg', 2, NULL, 17, NULL),
(7, 'Love In Vain', 2014, '', 14, '', 'https://www.glenat.com/sites/default/files/styles/large/public/images/livres/couv/9782344003398-T.jpg?itok=R3SjxiZG', 2, NULL, 18, NULL),
(8, 'Panthère', 2014, '', 11, '', 'https://www.actes-sud.fr/sites/default/files/couv_jpg/9782330036805.jpg', 2, NULL, 19, NULL),
(9, 'Gros Bois', 2014, '', 15, '', 'http://enfantsrouges.com/wp-content/uploads/2014/08/couverture-GB.gif', 4, NULL, 20, NULL),
(10, 'The Wake', 2015, '', 2, '', 'https://bdi.dlpdomain.com/album/9782365774208/couv/M385x862/the-wake.jpg', 4, NULL, 21, NULL),
(11, 'Little Tulip', 2014, '', 16, '', 'http://bdi.dlpdomain.com/album/9782803634170/couv/I325x456/little-tulip-tome-1-little-tulip.jpg', 4, NULL, 15, NULL),
(12, 'Un Vrai Guerrier', 2015, '', 17, '', 'https://www.bdnet.com/img/couvpage/12/9782918553120_cg.jpg', 4, NULL, 23, NULL),
(13, 'La colère de Fantomas', 2015, '', 3, '', 'https://www.bedetheque.com/media/Couvertures/Couv_178996.jpg', 5, NULL, 33, NULL),
(14, 'En temps de guerre', 2015, '', 22, '', 'https://www.bedetheque.com/media/Couvertures/Couv_239768.jpg', 5, NULL, 34, NULL),
(15, 'Poison city', 2015, '', 19, '', 'https://www.bedetheque.com/media/Couvertures/Couv_239791.jpg', 5, NULL, 35, NULL),
(16, 'Une tête bien vide', 2015, '', 23, '', 'https://www.bedetheque.com/media/Couvertures/Couv_237916.jpg', 5, NULL, 36, NULL),
(157, 'Gideon Falls', 2018, '17.5', 2, '9791026814580', 'https://bdi.dlpdomain.com/album/9791026814580/couv/M385x862/gideon-falls-tome-1.jpg', 40, NULL, 2, NULL),
(158, 'Spirou, le journal d\'un ingénu', 2011, '14.50', 5, '9782800154701', 'https://bdi.dlpdomain.com/album/9782800154701-couv-M800x1600.jpg', 40, NULL, 1, NULL),
(159, 'Horreur Cosmique', 2015, '22', 6, ' 9782878271904', 'http://www.editions-rackham.com/wp-content/uploads/2016/12/9782878271904-384x538.jpg', 40, NULL, 3, NULL),
(161, 'Héroïque Fantaisie', 2018, '20', 1, '978-2-84961-245-3', 'https://www.lesrequinsmarteaux.com/sites/default/files/styles/adaptive/adaptive-image/public/albums-couverture/couv_heroique_fantaisie-web.jpg?itok=5U0P-L2h', 41, NULL, 5, NULL),
(162, 'Belleville Story', 2010, '16,50', 3, '9782205063769', 'http://bdi.dlpdomain.com/album/9782205063769/couv/M320x500/belleville-story-tome-1-avant-minuit-1.jpg', 41, NULL, 7, NULL),
(163, 'Sweet Tooth', 2015, '22.5', 2, '9782365777148', 'https://bdi.dlpdomain.com/album/9782365777148/couv/M385x862/sweet-tooth-tome-1.jpg', 41, NULL, 6, NULL),
(164, 'Éclat(s) d\'âme', 2018, '7.95', 4, '9782369742739', 'http://www.akata.fr/sites/default/files/styles/image_publication/public/couvertures/eclat-ame-1.jpg?itok=FnrlHAWp', 41, NULL, 8, NULL),
(165, 'La terre des fils', 2017, '23', 7, '978-2-7548-2252-7', 'https://www.bedetheque.com/media/Couvertures/Couv_299328.jpg', 42, NULL, 9, NULL),
(166, 'My home hero', 2017, '', 18, '', 'https://www.manga-news.com/public/images/series/My-Home-Hero-1-kurokawa.jpg', 45, NULL, 29, NULL),
(167, 'Planètes', 1999, '', 20, '', 'https://www.manga-news.com/public/images/vols/planetes_01-2.jpg', 45, NULL, 30, NULL),
(168, 'In these words', 2011, '', 21, '', 'https://www.manga-news.com/public/images/series/in-these-words-temp.jpg', 45, NULL, 32, NULL),
(169, 'Bride Stories', 2009, '', 19, '', 'https://www.manga-news.com/public/images/series/Bride-Stories.jpg', 45, NULL, 31, NULL),
(170, 'Comme un frisson', 2017, '', 8, '', 'https://www.bedetheque.com/cache/thb_couv/Couv_312069.jpg', 42, NULL, 10, NULL),
(171, 'Patience', 2016, '', 9, '', 'https://www.bedetheque.com/cache/thb_couv/Couv_289443.jpg', 42, NULL, 12, NULL),
(172, 'Les nuits d\'Aksehir', 2017, '', 4, '', 'https://www.bedetheque.com/media/Couvertures/Couv_302689.jpg', 42, NULL, 11, NULL),
(173, 'Sheriff of Babylon', 2018, '', 2, '', 'https://www.bedetheque.com/media/Couvertures/Couv_343666.jpg', 46, NULL, 40, NULL),
(174, 'Ted drôle de coco', 2018, '', 23, '', 'http://atrabile.org/wp-content/files_mf/cache/th_362ad82be520c4a2c6f4d8fb42218792_ted_couv268.png', 46, NULL, 38, NULL),
(175, 'Bezimena', 2018, '', 25, '', 'https://www.bedetheque.com/media/Couvertures/Couv_345343.jpg', 46, NULL, 39, NULL),
(176, 'Neska', 2016, '', 24, '', 'https://www.editions-delcourt.fr/images/rsz/f7/f7a6ff2bea73e9722e5a82aa4492f49b.jpg', 46, NULL, 37, NULL),
(177, 'Le trône d\'Argile', 2006, '', 24, '', 'https://www.bedetheque.com/cache/thb_couv/Couv_55167.jpg', 47, NULL, 45, NULL),
(178, 'Gokinjo', 2004, '', 24, '', 'https://www.bedetheque.com/cache/thb_couv/gokinjo1couv_40412.jpg', 47, NULL, 44, NULL),
(179, 'Maléfiques', 2019, '', 28, '', 'https://www.bedetheque.com/cache/thb_couv/Couv_369907.jpg', 47, NULL, 43, NULL),
(180, 'Jean Doux et la disquette molle', 2017, '', 24, '', 'https://www.bedetheque.com/cache/thb_couv/Couv_297597.jpg', 47, NULL, 46, NULL),
(181, 'La saison des roses', 2019, '', 27, '', 'https://content.flblb.com/uploads/2019/07/SaisonRoses-SELECTION-453x640.jpg', 48, 51, 42, 51),
(182, 'Passions', 2014, '', 26, '', 'http://www.planetebd.com/dynamicImages/album/cover/large/22/78/album-cover-large-22788.jpg', 48, NULL, 41, NULL),
(183, 'Mister Miracle', 2018, '', 2, '', 'https://bdi.dlpdomain.com/album/9791026815167/couv/M385x862/mr-miracle.jpg', 48, NULL, 2, NULL),
(184, 'Opus', 2013, '', 13, '', 'https://www.bedetheque.com/media/Couvertures/Couv_190906.jpg', 48, NULL, 18, NULL),
(185, 'Vingt-trois prostituées', 2012, '', 9, '', 'https://www.bedetheque.com/media/Couvertures/Couv_172946.jpg', 52, NULL, 47, NULL),
(188, 'La virginité passé 30 ans', 2018, '', 4, '', 'https://www.bedetheque.com/media/Couvertures/Couv_327035.jpg', 52, NULL, 3, NULL),
(189, 'Déesse', 2019, '', 1, '', 'https://www.lesrequinsmarteaux.com/sites/default/files/styles/adaptive/adaptive-image/public/albums-couverture/sicker01.jpeg?itok=jV-mQbma', 52, NULL, 48, NULL),
(190, 'Otto ou l’île miroir', 2018, '', 30, '', 'https://images.leslibraires.ca/books/9782919242870/front/9782919242870_large.jpg', 52, NULL, 49, NULL),
(191, 'Nako', 2019, '', 31, '', 'https://www.bedetheque.com/media/Couvertures/Couv_365677.jpg', 51, NULL, 52, NULL),
(192, 'Raowl', 2019, '', 5, '', 'https://bdi.dlpdomain.com/album/9791034730384-couv-M800x1600.jpg', 51, NULL, 50, NULL),
(193, 'Peau de mille bêtes', 2019, '', 24, '', 'https://www.bedetheque.com/media/Couvertures/Couv_361167.jpg', 51, NULL, 53, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `livres_auteurs`
--

CREATE TABLE `livres_auteurs` (
  `idLivresAuteurs` smallint(6) NOT NULL,
  `id_livre` int(6) NOT NULL,
  `id_auteur` int(6) NOT NULL,
  `id_dessinateur` int(6) DEFAULT NULL,
  `autres` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `livres_auteurs`
--

INSERT INTO `livres_auteurs` (`idLivresAuteurs`, `id_livre`, `id_auteur`, `id_dessinateur`, `autres`) VALUES
(1, 162, 4, NULL, NULL),
(2, 157, 1, 1, NULL),
(3, 159, 6, NULL, NULL),
(5, 158, 5, NULL, NULL),
(6, 163, 1, NULL, NULL),
(7, 164, 2, NULL, NULL),
(11, 161, 3, NULL, NULL),
(12, 165, 8, NULL, NULL),
(13, 1, 12, NULL, NULL),
(14, 2, 13, NULL, NULL),
(15, 3, 14, NULL, NULL),
(16, 4, 15, NULL, NULL),
(17, 5, 16, NULL, NULL),
(18, 6, 17, NULL, NULL),
(19, 7, 18, 3, NULL),
(20, 8, 19, NULL, NULL),
(21, 166, 23, 5, NULL),
(22, 167, 21, NULL, NULL),
(23, 168, 20, NULL, NULL),
(24, 169, 22, NULL, NULL),
(25, 9, 24, NULL, NULL),
(26, 10, 25, NULL, NULL),
(27, 11, 26, NULL, NULL),
(28, 12, 27, NULL, NULL),
(29, 172, 11, NULL, NULL),
(30, 170, 9, NULL, NULL),
(31, 171, 10, NULL, NULL),
(169, 176, 31, NULL, NULL),
(170, 175, 29, NULL, NULL),
(171, 173, 30, NULL, NULL),
(172, 174, 28, NULL, NULL),
(173, 181, 32, NULL, NULL),
(174, 182, 33, NULL, NULL),
(175, 183, 30, NULL, NULL),
(176, 184, 34, NULL, NULL),
(177, 185, 35, NULL, NULL),
(178, 189, 36, NULL, NULL),
(179, 188, 37, 6, NULL),
(180, 190, 39, NULL, NULL),
(181, 193, 42, NULL, NULL),
(182, 192, 40, NULL, NULL),
(183, 191, 41, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `idPhoto` smallint(11) NOT NULL,
  `src` varchar(45) DEFAULT NULL,
  `soiree_id` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `soirees`
--

CREATE TABLE `soirees` (
  `idSoiree` int(6) NOT NULL,
  `date_soiree` date NOT NULL,
  `nom` varchar(40) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `image` varchar(999) NOT NULL,
  `lieu` varchar(45) NOT NULL,
  `heure` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `soirees`
--

INSERT INTO `soirees` (`idSoiree`, `date_soiree`, `nom`, `description`, `image`, `lieu`, `heure`) VALUES
(1, '2014-11-05', '1', 'Venez échanger autour d\'un verre, à partir d’une sélection de quatre bandes dessinées, en compagnie de nos quatre chroniqueurs libraires !\r\nNous vous attendons le mercredi 5 novembre à 20h30 dans la salle du bar La Tireuse, situé au 18, rue Laplace, dans le 5e arrondissement de Paris.', 'https://i.imgur.com/h8fHLzd.jpg', 'La Tireuse', '20h30'),
(2, '2014-11-03', '2', 'Bonjour,\r\nLa prochaine soirée de La bande des idées aura lieu à 20h30 le Mercredi 3 décembre au bar La Tireuse, autour d\'une sélection de 4 bandes dessinées élaborée par 3 libraires : Sylviane (L\'atelier d\'en face), Mimoun (Bulles en vrac), Ludovic (L\'arbre à lettres Mouffetard) et une bibliothécaire : Pauline (Médiathèque Boris Vian) !', 'https://i.imgur.com/4GiOCIW.jpg', 'La Tireuse', '20h30'),
(3, '2015-02-11', '3', 'La prochaine soirée de La Bande des Idées aura lieu le mercredi 11 février à 20h30 au bar La Tireuse (18 rue Laplace, Paris 5e) !\r\n\r\nLes libraires : Céline (BDnet Bastille), Alex (La librairie de Paris), Christopher (BDnet Nation) & Ludovic (L\'Arbre à Lettres Mouffetard) échangeront avec vous autour de la sélection suivante :\r\n\r\n- La lune est blanche, d\'Emmanuel & François Lepage, Futuropolis.\r\n- Elle, de Francis Masse, L\'Association.\r\n- Mind game, de Robin Nishi, Editions IMHO.\r\n- Superman, identité secrète, de Kurt Busiek et Stuart Immonen, Urban Comics.', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/1979505_940848045958241_3510145053302013663_n.jpg?_nc_cat=106&_nc_ht=scontent.fcdg1-1.fna&oh=8269b537190194727d2638704f3d0445&oe=5D19A617', 'La Tireuse', '20h30'),
(4, '2015-10-03', '4', 'Rendez-vous à 20H30 le MARDI 10 MARS au Bar Le More (18 boulevard du Temple, Paris 11e / M° République - Filles du Calvaire).\r\n\r\nDeux libraires : Sophie de la Librairie La Manoeuvre, Pierre de la Librairie Fontaine Haussmann & deux bibliothécaires : Yannick, de la Médiathèque Boris Vian, et Églantine, vous parleront de :\r\n\r\n- Little tulip, François Boucq & Jérôme Charyn, Le Lombard 11/2014.\r\n- Gros bois, Jérémy Le Corvaisier, Les Enfants Rouges éditions, 11/2014.\r\n- The Wake, Snyder Scott & Murphy Sean, Urban Comics, 01/2015.\r\n- Un vrai guerrier ne meurt jamais même si ça signifie la mort, Antoine Marchalot, Arbitraire Editions, 02/2015.\r\n\r\nLa soirée sera animée par Mimoun !', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/11034300_957113717665007_9217857601948649037_n.jpg?_nc_cat=103&_nc_ht=scontent.fcdg1-1.fna&oh=81f0d6de3f3cdbfddf2b249453cd5ce6&oe=5D1D555D', 'Le more', '20h30'),
(5, '2015-03-10', '5', 'La prochaine soirée de La bande des idées aura lieu le mardi 7 avril à 20h30 au bar Chez Raymonde !\r\n\r\nLes chroniqueurs seront:\r\nChristophe Steffan, journaliste à Culturebd et Tric Trac\r\nJulia Segui, libraire à Texture Librairie\r\nPablo Yanover, libraire à BDnet Bastille\r\nEt Gwendoline Delaporte de la librairie PAGE 189\r\n\r\nIls débattront autour des titres suivants:\r\n- La Colère de Fantômas (3 tomes), Olivier Bocquet et J.Rocheleau Illustration & Bande dessinée., Dargaud\r\n- Une tete bien vide, Gilbert Hernandez, Les éditions Atrabile\r\n- Poison City, Tetsuya Tsutsui, Ki-oon Éditions\r\n- En temps de guerre, Delphine Panique , Misma Editions\r\n\r\nA mardi !', 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/10474535_973957882647257_8113608325421000787_n.jpg?_nc_cat=110&_nc_ht=scontent-cdg2-1.xx&oh=eaa2a27041cc5272bb5f3b88b23b50ee&oe=5D75FBF5', 'Chez Raymonde', '20h30'),
(6, '2015-05-05', '6', 'Mardi 5 mai, Chez Raymonde (104, boulevard Richard Lenoir, Parie 11e), à 20h30, Samuel de la Librairie L\'atelier 9 (9e), Tiph Aine de la Librairie Le Méandre (Meudon), Mimoun de la librairie Bulles en vrac (5e) & Guix de la Librairie La dimension fantastique (10e) nous parleront de :\r\n- All Star Superman, Grant Morrison & Frank Quitely, Urban Comics, 06.13\r\n- Rose profond, Jean-Pierre Dionnet & Michel Pirus, Editions Casterman BD, 04.15\r\n- La tendresse des pierres, Marion Fayolle, Magnani, 10.13\r\n- L\'encyclopédie des débuts de la terre, Isabel Greenberg, Casterman, 01.15\r\n\r\n', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/11110292_990154227694289_4228029765977675487_n.jpg?_nc_cat=109&_nc_ht=scontent.fcdg1-1.fna&oh=49cff7095ebfe210da24d43e044cf75b&oe=5D247C54', 'Chez Raymonde', '20h30'),
(7, '2015-06-02', '7', 'Bonjour !\r\n\r\nLe mardi 2 juin, à 20h30, toujours Chez Raymonde, 4 apprentis libraires de INFL - Institut National de Formation de la Librairie : Johan de La Rubrique à Bulles, Morgane de Librairie Super Héros, Thomas du Le comptoir des mots & Tiphaine de BDnet Nation vous parleront de :\r\n- La république du catch, Nicolas de Crécy, Editions Casterman BD, avril 2015.\r\n- Six-Gun Gorilla, Simon Spurrier & Jeff Stokely, Ankama Editions, avril 2015.\r\n- Renégat, Alex Baladi, The Hoochie Coochie, août 2012.\r\n- Jolies ténèbres, Kerascoët & Fabien Vehlmann, Les Éditions Dupuis, mars 2009.\r\nLa soirée sera présentée par Ludovic !\r\n\r\nA bientôt !\r\nInès, Ludovic & Mimoun', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/11351345_1006130122763366_7087995029299373561_n.jpg?_nc_cat=108&_nc_ht=scontent.fcdg1-1.fna&oh=98ce37ea32d0cdbbaae6edf9b8232d3b&oe=5D233300', 'INFL', '20h30'),
(8, '2015-07-07', '8', 'Pour la dernière de La bande des idées de l\'année, le mardi 7 juillet à 20h30 Chez Raymonde, nous accueillons 4 libraires : Joseph de BDnet Nation, Sasha de la Librairie des Batignolles, Baptiste de Bulles en vrac et Céline de BDnet Bastille, qui ont respectivement choisi de défendre :\r\n- Le sculpteur, Scott McCloud, Rue de Sèvres\r\n- Daddy\'s girl, Debbie Drechsler, L\'Association\r\n- La fille de la plage tomes 1&2, Inio Asano, Editions IMHO\r\n- Racket, Stéphane Levallois, Futuropolis\r\n\r\nLa soirée sera présentée par Mimoun !\r\n', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/10985918_1027020130674365_87534998117886051_n.jpg?_nc_cat=105&_nc_ht=scontent.fcdg1-1.fna&oh=ea8e749d604e38f1e9846738e72c660c&oe=5D210011', 'Chez Raymonde', '20h30'),
(9, '2015-10-05', '9', 'C\'est le retour de la BDI!\r\n\r\nPour cette première chez Lou Pascalou; Sylviane, Alex, Ludo et Gwendoline nous présenterons respectivement:\r\n- Hobo Mom de Max de Radiguès aux éditions L\'Employé du Moi\r\n- Titeuf, Bienvenue en adolescence, de Zep aux éditions Glénat\r\n- Fraction de Shintaro Kago aux éditions IMHO\r\n- Pauline à Paris de Benoit Vidal aux éditions FLBLB\r\n\r\nLa soirée sera présentée par Inès !\r\n', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t31.0-8/12045710_1075450439164667_5971117612948959248_o.jpg?_nc_cat=105&_nc_ht=scontent.fcdg1-1.fna&oh=2005aa0f4bd6e914288ea3cbbf06b561&oe=5D1A90BF', 'Chez Raymonde', '20h30'),
(10, '2015-11-02', '10', 'Pour cette dixieme bande des idées; Thomas, Marion, Gwendoline et Fabien présenteront respectivement:\r\n- Cigish de Florence Dupré la Tour aux éditions Ankama\r\n- Le grand méchant renard de Benjamin Renner aux édtions Delcourt\r\n- Tel qu\'en lui même enfin de Killoffer aux édtions l\'Association\r\n- Mitterand, un jeune homme de droite de Philippe Richelle et Frédéric Rébéna aux éditions Rue de Sèvres\r\nLa soirée sera presentée par Mimoun!', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12143197_1088158194560558_7531947012850699320_n.jpg?_nc_cat=103&_nc_ht=scontent.fcdg1-1.fna&oh=8fcf6b47f7fc43af14416790905a7ae4&oe=5D13A4C5', 'Lou Pascalou', '20h30'),
(11, '2015-12-07', '11', 'La bande des idées #11 aura lieu le lundi 7 décembre au Lou Pascalou à 20h30.\r\nLa sélection sera composée de :\r\n- Facteur pour femmes de Didier Quella-Guyot et\r\nSébastien Morice chez Grand Angle Editions, présenté par Thierry, journaliste pour le magazine ZOO (bande dessinée) et le site Cases d\'Histoire\r\n- Trashed de Derf Backderf aux Éditions çà et là, présenté par Mathilde de la Librairie Au Labyrinthe (Saint-Germain-en-Laye)\r\n- Ladyboy vs Yakuzas de Toshifumi Sakurai aux éditions Akata, présenté par Alan de la Librairie Bulles de Salon (XIVème).\r\n- Le temps est proche de Christopher Hittinger aux éditions The Hoochie Coochie, présenté par Morgane de la Librairie l Atelier (XIXème)\r\nLa soirée sera animée par Ludovic !', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12299298_1103504503025927_7896546280449256768_n.jpg?_nc_cat=106&_nc_ht=scontent.fcdg1-1.fna&oh=d0cf1655bccbc7a5ce24bb2427075636&oe=5CE1E329\r\n\r\n', 'Lou Pascalou', '20h30'),
(12, '2016-01-04', '12', 'L\'année 2016 de La bande des idées débutera Le 4 janvier à 20h30 avec une spéciale éditeurs!\r\n- Camille, chargée d\'événementiel pour Les Éditions Dupuis, nous présentera Comment faire fortune en juin 40 de Fabien Nury, Xavier Dorison et Laurent Astier paru chez Casterman BD.\r\n- Catherine,chargée des relations librairies de L\'Association, nous présentera l\'intégrale Gazoline de Jano, paru chez Les Requins Marteaux Éditions\r\n- Yannick, directeur de collection aux Éditions Delcourt nous présentera Vater und sohn de Erich Ohser paru chez Warum / Vraoum.\r\n- Serge, éditeur des Éditions çà et là nous présentera Green Lantern & Green Arrow de Dennis O\'Neil et Neal Adams paru chez Urban Comics\r\n\r\nLa soirée sera animée par Inès!', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12366279_1115525188490525_3444939567555188617_n.jpg?_nc_cat=105&_nc_ht=scontent.fcdg1-1.fna&oh=eed31df2dc72374d64e21c71c9d94404&oe=5CE15C43', 'Lou Pascalou', '20h30'),
(13, '2016-02-01', '13', 'La BDI#13, c\'est le lundi 1er fevrier au Lou Pascalou !\r\nAu programme:\r\n\r\n- Louise de la librairie le Point De Côté à Suresnes nous présentera Carnet de santé foireuse de Pozla, paru aux Éditions Delcourt.\r\n- Christopher de la librairie BDnet Nation nous parlera du Dernier arpenteur des sables de Jay Hosler aux Éditions Cambourakis.\r\n- Sophie, ancienne libraire et modératrice de débats, nous fera découvrir Feu de paille d\'Adrien Demont paru chez 6 Pieds Sous Terre.\r\n- Samuel; libraire, illustrateur et blogueur (Ma vie est un échec), nous présentera Stigmates de l\'italien Lorenzo Mattotti disponible aux éditions Casterman BD.\r\n\r\nEnfin, au lendemain du Festival International de la Bande Dessinée d\'Angoulême, nous ne manquerons pas de parler du palmarès de cette édition.\r\n\r\nLa soirée sera animée par Mimoun!\r\nAfficher moins', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12670605_1147488151960895_4559904947676418394_n.jpg?_nc_cat=106&_nc_ht=scontent.fcdg1-1.fna&oh=b0bbf60421aba76321873b82c2394a07&oe=5D1FC826', 'Lou Pascalou', '20h30'),
(14, '2016-03-07', '14', 'Une belle sélection pour la quatorzième Bande des idées!\r\nRendez-vous le 7 mars au Lou Pascalou où Côme de la Librairie Super Héros, TIphaine de BDnet Nation, Elise de la Librairie L\'Emile & Librairie Ars Huna et Romain de la librairie 45ème Parallèle à Pessac nous présenteront respectivement:\r\n- Punk Rock Jesus de Sean Murphy, paru chez Urban Comics\r\n- L\'attente infinie de Julia Wertz, édité par L\'Agrume Éditions\r\n- La paresse du panda de Fred Bernard, paru chez Casterman \r\n- Blues de Sergio Toppi edité par Editions Mosquito\r\nLa soirée sera animée par Ludovic !', '\r\nTableau suivi BDI maj 9mars \r\nTableau suivi BDI maj 9mars \r\n100%\r\n12\r\n\r\nhttps://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12670605_1147488151960895_4559904947676418394_n.jpg?_nc_cat=106&_nc_ht=scontent.fcdg1-1.fna&oh=b0bbf60421aba76321873b82c2394a07&oe=5D1FC826\r\nLa compatibilité du lecteur d\'écran est activée.\r\n \r\n \r\n 		\r\n\r\nhttps://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12670605_1147488151960895_4559904947676418394_n.jpg?_nc_cat=106&_nc_ht=scontent.fcdg1-1.fna&oh=b0bbf60421aba76321873b82c2394a07&oe=5D1FC826\r\n \r\n', 'Lou Pascalou', '20h30'),
(15, '2016-04-04', '15', 'Une belle sélection pour la quatorzième Bande des idées!\r\nRendez-vous le 7 mars au Lou Pascalou où Côme de la Librairie Super Héros, TIphaine de BDnet Nation, Elise de la Librairie L\'Emile & Librairie Ars Huna et Romain de la librairie 45ème Parallèle à Pessac nous présenteront respectivement:\r\n- Punk Rock Jesus de Sean Murphy, paru chez Urban Comics\r\n- L\'attente infinie de Julia Wertz, édité par L\'Agrume Éditions\r\n- La paresse du panda de Fred Bernard, paru chez Casterman \r\n- Blues de Sergio Toppi edité par Editions Mosquito\r\nLa soirée sera animée par Ludovic !', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/12376363_1180131635363213_4825001361981708091_n.jpg?_nc_cat=111&_nc_ht=scontent.fcdg1-1.fna&oh=e3961e663509c86cc1a543edcaf18a58&oe=5D2174C7', 'Lou Pascalou', '20h30'),
(16, '2016-05-02', '16', 'Bonjour à tous !\r\nAlexandre de la Librairie de Paris nous présentera Mickey\'s craziest adventures de Lewis Trondheim et Nicolas Keramidas aux Éditions Glénat BD.\r\nChristophe, chroniqueur pour Culturebd et Tric Trac nous présentera Presque de Manu Larcenet aux Editions Les Rêveurs.\r\nLucie, journaliste pour l\'Humanité, AAARG et Le calamar noir, nous présentera Medley de Emre Orhun aux Éditions Même Pas Mal.\r\nEnfin, Marie, lectrice passionnée et habituée de la bande des idées nous présentera le Journal de Julie Delporte publié à L\'Agrume Éditions.\r\nLa soirée sera présentée par le beau et ténébreux Ludo!', 'https://scontent.fcdg1-1.fna.fbcdn.net/v/t1.0-9/11140352_1199781990064844_3792389615048652994_n.jpg?_nc_cat=101&_nc_ht=scontent.fcdg1-1.fna&oh=2b5ac277c88d4bf7ddea7177c940df5d&oe=5D23FD22', 'Lou Pascalou', '20h30'),
(17, '2016-05-30', '17', 'La bande des idées #17, spéciale apprentis, aura exceptionnellement lieu le 30 mai à 20h30 dans les locaux de l\' INFL - Institut National de Formation de la Librairie (entrée par la rue Kleber, 93100 Montreuil, Métro Croix de Chavaux).\r\nLe buffet se composera de plats et boissons (softs, vin, bière) que chacun apportera !\r\n\r\nAu programme de la soirée:\r\n\r\nSébastien de la Librairie Super Héros nous présentera L\'odeur des garçons affamés de Loo Hui Phang et Frederik Peeters paru chez Casterman BD.\r\nLéna de la librairie La Rubrique à Bulles nous présentera Le confesseur sauvage de Philippe Foerster publié chez Éditions Glénat BD. \r\nDiego de la Librairie Palimpseste nous parlera manga avec Orange de Takano Ichigo - 高野苺 aux éditions Akata.\r\nNolwenn, étudiante en master de politique éditoriale en apprentissage aux Éditions çà et là nous présentera Les spectateurs de Victor Hussenot édité par Les bandes dessinées Gallimard.\r\nLa soirée sera présentée par Mimoun !', 'https://scontent-cdt1-1.xx.fbcdn.net/v/t1.0-9/13177596_1211136378929405_1892386029205842518_n.jpg?_nc_cat=111&_nc_ht=scontent-cdt1-1.xx&oh=5a9a5d2b3599ffd40817ef828cf4a1a8&oe=5D0C02F6', 'INFL', '20h30'),
(18, '2016-06-27', '18', 'Bonjour à tous !\r\n\r\nLa dernière bande des idées de l\'année aura lieu LUNDI 27 JUIN à 20h30 au Lou Pascalou !\r\n\r\nVoici la sélection, concoctée par nos 4 chroniqueurs :\r\n\r\n- Alexia, formatrice à l\'INFL - Institut National de Formation de la Librairie, présentera L\'homme qui tua Lucky Luke de Matthieu Bonhomme, édité par Lucky comics en avril 2016.\r\n\r\n- Mimoun, libraire à Bulles en vrac, s\'accorde avec l\'actualité et défendra Hors-jeu de Matthieu Chiara, paru à L\'Agrume Éditions en avril 2016.\r\n\r\n- Lauriane, de la Librairie L\'Emile et formatrice à l\'INFL - Institut National de Formation de la Librairie, soutiendra Le concile des arbres de Pierre Boisserie & Nicolas Bara, édité par Dargaud en avril 2016.\r\n\r\n- Damien, libraire à la Librairie l\'Imagigraphe, parlera de White Trash de Gordon Rennie & Martin Emond paru à Ankama Editions en mai 2016.\r\n\r\nBelle journée et à lundi !', 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/13407301_1238484292861280_6451655614105249900_n.jpg?_nc_cat=108&_nc_ht=scontent-cdg2-1.xx&oh=990c2d21982a0ad2f8196e768a1541fe&oe=5D6FBC4E', 'Lou Pascalou', '20h30'),
(36, '2018-06-04', '36', 'La bande des idées #36 est une spéciale apprentis, elle aura lieu  le 4 juin à l\'INFL à partir de 20h30 !  - « Y le dernier homme » de Brian K Vaughan et Pia Guerra édité par Urban Comics sera présenté par Myrtille de la librairie du Mémorial de la Shoah,  - « Alcoolique » de Jonathan Ames et Dean Haspiel, édité par Monsieur Toussaint Louverture sera présenté par Marjorie de la librairie Le Livre et la Tortue, - « Bouche du diable » de Charyn et Boucq, édité par Casterman BD, sera presenté par Théo-Paul de la Librairie ARS UNA, - « Mémoires d’un frêne » de Park Kun-Wong, édité par les éditions Rue de l’échiquier sera présenté par Jérôme de La librairie du canal.  Aux commandes de la soirée : l\'excellent Baptiste ! - - - - - - - - Infos pratiques : Le buffet se composera de plats et boissons (softs, vin, bière) que chacun apportera !  Pour venir, prenez la sortie 4 du métro Croix de Chavaux, puis la rue Kléber, l\'INFL est au n°7 à quelques minutes, juste à coté du Pole Emploi.', 'https://scontent-cdt1-1.xx.fbcdn.net/v/t1.0-9/33765875_1968566439853058_6763955458291007488_n.jpg?_nc_cat=110&_nc_ht=scontent-cdt1-1.xx&oh=2177f89d07cadf3c9b0abcf5878aace8&oe=5CF46CA6', 'INFL', '20h30'),
(37, '2018-09-03', '37', 'Après un été embrasé, le thermostat commence à se calmer, le moment idéal pour vous annoncer LA RENTRÉE DE LA BANDE DES IDÉES : retrouvons-nous le 3 septembre au Lou Pascalou pour parler BD, discuter, contester, négocier, mais surtout s\'amuser !  A la table des chroniqueurs pour cette 37e édition :  - **PAUL**, libraire à BDnet Bastille vous présentera le tome 1 du comic \"Deadly class\" des éditions Urban Comics de sa voix de crooner ;  - **MATHILDE**, pas libraire qui s\'occupe de la com\' de la bande des idées vous parlera de \"Moi ce que j\'aime c\'est les monstres\", une petite perle de Emil Ferris qui vient d\'être éditée en français par Monsieur Toussaint Louverture ;  - **SEAN**, de la librairie du MK2 quai de Loire vous proposera le manga \"Mimikaki\" de Yarô Abe récemment édité en français par Le Lézard Noir ;  - **ELSA**, future libraire de l\'Humeur Vagabonde (à partir de septembre) défendra \"Beverly\", le 1er roman graphique de Nick drnaso publié par les Éditions Presque Lune.  La soirée sera présentée par le', 'https://scontent-cdt1-1.xx.fbcdn.net/v/t1.0-9/40054328_2110024205707280_5284287186995249152_n.jpg?_nc_cat=106&_nc_ht=scontent-cdt1-1.xx&oh=325ae9f52e9687d7752be310b1b5c58d&oe=5CBA13FC', 'Lou Pascalou', '20h30'),
(38, '2018-12-01', '38', 'Nous vous attendons lundi 1er octobre au Lou Pascalou pour une nouvelle **Bande des idées** automnale ! Pour cette 38e édition, nous accueillerons :\r\n- MATHIAS, illustrateur, qui nous parlera du comic Seconds de Bryan Lee O\'Malley chez Dargaud. \r\nMAXIME, chargé d\'enseignement en histoire de l\'art, qui nous présentera le manga L\'ère des cristaux d\'Haruko Ichikawa aux éditions Glénat Manga. INÈS, fondatrice de la Bande des idées, qui défendra Boris l\'enfant patate, BD indépendante d\'Anne Simon éditée chez misma. CLOTILDE, scénariste, présentera le Grand mort de Vincent Mallié, Régis Loisel et Jean-Blaise Djian, série fantastique publiée par Les Éditions Vents d\'Ouest.', 'https://scontent-cdt1-1.xx.fbcdn.net/v/t1.0-9/42607884_2150476651662035_5013794029343604736_n.jpg?_nc_cat=110&_nc_ht=scontent-cdt1-1.xx&oh=8cf3e7001016736572e642471fa90751&oe=5CACD1B2', 'Lou Pascalou', '20h30'),
(39, '2018-11-04', '39', 'RDV le lundi 5 novembre au Lou Pascalou pour la 39e Bande des idées ! \r\n\r\nAutour de la table des chroniqueurs nous accueillerons : \r\n\r\n- FLORE, libraire chez BDnet Bastille qui présentera \"Les filles de Salem\", éditée par Dargaud\r\n\r\n- DIEGO, libraire à Bulles En Tête et célèbre organisateur de la BDI aux cheveux soyeux qui nous parlera de \"Jojo bizarre adventure - Diamond is unbreakable\" aux éditions Delcourt/Tonkam\r\n\r\n- GENTIANE, fervente amatrice de BD qui défendra \"Dernier test avant l\'apocalypse\" éditée chez Delcourt/Tonkam\r\n\r\n- DESIRE, libraire et autre organisateur de la BDI qui présentera \"La mère et la mort\" éditée chez Le Tripode.\r\n\r\nNous vous attendons nombreux et sur-motivés pour cette édition présentée par MATHILDE !', 'https://scontent-cdt1-1.xx.fbcdn.net/v/t1.0-9/44245490_2179972502045783_4181771306905108480_n.jpg?_nc_cat=107&_nc_ht=scontent-cdt1-1.xx&oh=a8e72b909b78185337788d13182aa349&oe=5CB24426', 'Lou Pascalou', '20h30'),
(40, '2018-12-03', '40', 'Venez célébrer la 40e Bande des Idées avec nous le lundi 3 décembre au Lou Pascalou !\r\n\r\nAu programme de cette 40e édition : du comics, de la franco-belge, de l\'indé et du manga ; un savoureux mélange qui promet de beaux échanges ! \r\n\r\n- SASHA, des Libraires volants nous présentera \"Journal d’un ingénu\" et \"L’espoir malgré tout\", le Spirou d’Émile Bravo aux Éditions Dupuis\r\n\r\n- CHARLOTTE, de Bulles en vrac nous parlera de \"Gideon falls\" de Jeff Lemire et Andrea Sorrentino édité par Urban Comics\r\n\r\n- CÔME, défendra \"Horreur cosmique\" de Peppe Koivunen et Aapo Rapi aux Editions Rackham\r\n\r\n- SHYLE, quant à lui, présentera \"L’art de la vulve une obscénité ?\" de Rokudenashiko des Éditions Presque Lune\r\n\r\nLa soirée sera animée par QUENTIN, ce sera sa première fois, alors vous serez très gentil avec lui !', 'https://imagizer.imageshack.com/v2/1202x438q90/923/IZAwCa.png', 'Lou Pascalou', '20h30'),
(41, '2019-01-07', '41', 'Retrouvez-nous au Lou Pascalou pour la première BDI de l\'année !\r\n\r\nAux manettes de cette 41e édition : la grande MARION !\r\n\r\nA la table des chroniqueurs.ses :\r\n- Tatiana présentera \"Eclat(s) d’âme\", le manga de Yuhki Kamatani édité par Akata \r\n- Olivia présentera \"Sweet Thoot\" un comics de Jeff Lemire édité par Urban Comics\r\n- Côme (celui de la Librairie Super Héros) présentera \"Héroïque fantaisie\" d’Olivier Texier publié par Les Requins Marteaux Éditions\r\n- Damien présentera \"Bellevile story\" d’Arnaud Malherbe et Vincent Perriot édité par Dargaud.\r\n\r\nD\'ici là, beaucoup de courage aux libraires et de bonnes fêtes à tout le monde !', 'https://imageshack.com/a/img924/234/gcYhnx.png', 'Lou Pascalou', '20h30'),
(42, '2019-02-04', '42', 'RDV au Lou Pascalou pour la 42e BDI ! A la table des chroniqueurs.ses :\r\n☆ Augustin et \"La terre des fils\" de Gipi édité par Futuropolis\r\n☆ Johan et \"Comme un frisson\" d\'Aniss El Hamouri édité par Vide Cocagne\r\n☆ Marie-Charlotte et \"Patience\" de Daniel Clowes des Éditions Cornélius\r\n☆ Manon et \"les nuits d\'aksehir \" d’Ichikawa Raku édité par Akata \r\n\r\nA la présentation : \r\n☆ Mathilde \r\n\r\nDans le public :\r\n☆ Vous ', 'https://scontent-cdg2-1.xx.fbcdn.net/v/t1.0-9/50107976_2325276887515343_3952296160672088064_n.jpg?_nc_cat=105&_nc_ht=scontent-cdg2-1.xx&oh=5c53c24c0237450b9581e79fcc2c29be&oe=5CF31200', 'Lou Pascalou', '20h30'),
(43, '2019-03-04', '43', 'RDV au Lou Pascalou le 4 mars prochain pour la 43e BDI !  \r\n\r\nA la table des chroniqueurs.ses :\r\n☆ Florian défendra \"La balade nationale\" de Venayre et Davodeau, aux Editions La Découverte.  \r\n☆  Léna présentera \"Beastars\" de Itagaki, paru chez Ki-oon Éditions.\r\n☆  Myrtille nous fera découvrir \"Dans un rayon de soleil\" de Walden, édité chez Gallimard BD.\r\n☆  Christopher présentera \"Macadam Byzance \" de Starsky et Place, édité par Fluide Glacial.\r\n\r\nA la présentation : \r\n☆ Quentin', 'https://lh3.googleusercontent.com/kP4i987jLYzjl1n6LqNdFV0ToKgJXkq8C_VB-vLm_GbVHsjzHVmEWRj4XQZD_x2NlaA4Riq1LtqD242rcAgIr9cK6ZVAFfD-B3JOK4emaVOhwTjRx6bipsKrw4i4A5YntjARtGfDJHtCVilqeN0OhE3DKltSC1PsXhiKdWEtx8KN_clWnh9F2C0rc-mUDOBr69iwZsM9bpuRylaNTbmwHN066f7ylSfYVbvZf04ETc66Z6HWlieXEcwn-S4UAF8slpHSfY31pERSFtz6Wn-eKC3Usi0faYiDVcphpw7G_z4K60MDldDS5Y0mV2aqoz8LB6gpHLhjEyPWXJF62qDjJ5iUFW5Pa9x-2ICphQbs-QE2Nw11q2mM1Yh4kHhe3g6FR0-fcmAzI-SZrBin7iIc1abjHhlsdjjE5BF55NFVbBg1v_wrjpZCEJ3ldHV-FhNWIxGLC0Bl98bmCWh4ViQSq17kvfM-l8MweQVSHMhK-i3GesbNoVKzyrzd3HUb5jwm5PffFO83mAcTeh8368e69U2Cx-ldYzuD6kNxe_bYcVV_2aZhsHZ3FO8aI5jIVI4A8q1TCcm2hzhxlm-0moCO7va3Yv0jGYTbI_EISxWey6Jdg1RaLoMTL9Q2QLiAhIJS7B_CAYTPVV9O06cIDoVLo8S0T41l4l4=w959-h348-no', 'Lou Pascalou', '20h30'),
(44, '2019-04-01', '44', 'RDV au Lou Pascalou le 1er avril prochain pour la 44e BDI !  \r\n\r\nA la table des chroniqueurs.ses :\r\n☆ Samuel Polux libraire à L\'atelier 9 présentera Le dernier Atlas publié aux Éditions Dupuis\r\n☆ Tatiana Tabary libraire à Bdnet Nation parlera d\'Extases disponible chez Casterman BD\r\n☆ Basile, éditeur, défendra Extremity publié chez Delcourt Comics\r\n☆ Anne Teuf, autrice, proposera MW disponible cette fois chez Delcourt/Tonkam \r\n\r\n\r\nA la présentation : \r\n C\'est le retour du sémillant Diego Perez de Arce.', 'https://i.imgur.com/q3wYSRv.jpg', 'Lou Pascalou', '20h30'),
(45, '2019-05-06', '45', 'Ne cherchez plus, le 6 mai vous serez avec nous au Lou Pascalou pour une spéciale MANGA ! \r\n\r\nNous avons réuni les plus grand.es expert.es du manga DU MONDE pour vous présenter la crème de la crème :\r\n∙ Marion, mega responsable jeunesse de la librairie Les mots & les choses présentera \"My home hero\" (2 tomes) manga seinen de Ki-oon Éditions\r\n∙ Pierre, super enseignant et-c\'est-tout-ce-que-vous-saurez partagera son amour pour \"Planètes\", manga seinen édité par Panini Collections\r\n∙ Raphaëlle, fascinante libraire au mk2 Quai de Loire, parlera de \"In these words\", bd yaoi éditée par Manga Taifu \r\n∙ Sébastien, grand assistant de production chez Xilam animation nous racontera des \"Bride stories\", manga seinen édité par Kurokawa. \r\n\r\nEt pour présenter cette 45e édition, qui de plus parfaitement ajusté que le sémillant Désiré Mc Cann ? \r\n\r\nまたね !\r\n(Ça veut dire \"On se retrouve le 6 mai au Lou Pascalou autour d\'une bière/d\'un jus de papaye\")', 'https://i.imgur.com/Vhhu90b.png', 'Lou Pascalou', '20h30'),
(46, '2019-06-03', '46', 'Le 3 juin prochain, la BDI déménage provisoirement dans les locaux de l\'Institut National de Formation de la Librairie (INFL) pour une spéciale apprentis.\r\n\r\nMais qui, qui présentera quoi ?\r\n∙ Antoine présentera NESKA de Louise Joor aux Éditions Delcourt\r\n∙ Anaïs nous parlera de TED DRÔLE DE COCO d’Emilie Gleason publié par Les éditions Atrabile\r\n∙ Clémentine nous recommandera BEZIMENA de Nina Bunjevac chez Ici Même Editions \r\n∙ Léo présentera SHERIFF OF BABYLON de Tom King et Mitch Gerads édité par Urban Comics\r\n\r\n-> Comme nous ne serons pas dans un bar/restau, n\'hésitez pas à  rapporter de quoi se sustenter (chips, biscuits apéro, saucisson pour les plus riches...) et se désaltérer (softs, vin, bière) \r\n\r\n-> Pour venir, prenez la sortie 4 du métro Croix de Chavaux, puis la rue Kléber, l\'INFL est au n°7 à quelques minutes, juste à coté du Pole Emploi (n\'y voir aucun symbole).', 'https://i.imgur.com/feMle1l.png', 'INFL', '20h'),
(47, '2019-07-07', '47', 'C\'est l\'été, on se permet une grosse blague. Venez assister à cette bdi surprise.', 'https://i.imgur.com/ViZzOd5.jpg', 'Lou Pascalou', '20h30'),
(48, '2019-09-02', '48', 'C\'est la rentrée! La bande des idées est de retour pour des débats toujours plus enflammés ! \r\n\r\nRendez vous au Lou Pascalou le lundi 2 septembre à 20h30. \r\nA la table des chroniqueurs : \r\n\r\n☆ Youen Le Thellec, auteur-compositeur-chanteur-multi casquettes présentera Passions de Goossens dispo chez Fluide Glacial\r\n☆ Elsa Mittelette, libraire et créatrice de la newsletter #BooksByWomen nous parlera de Saison des Roses de Chloé Wary aux Éditions FLBLB\r\n☆ Charlotte Bradin libraire à BDnet Bastille présentera Mister Miracle de  Tom King et Mitch Gerads publié chez Urban Comics\r\n☆ Mimoun Larrssi fera son grand retour avec Opus de Satoshi Kon des Editions IMHO\r\n\r\nA la présentation et en première mondiale : \r\nOlivia Zeboudj', 'https://i.imgur.com/mgn1FYc.jpg', 'Lou Pascalou', '20h30'),
(51, '2019-11-27', '51', 'Une bande des idées hors les murs au Salon du livre et de la presse jeunesse en Seine-Saint-Denis entre deux classes de 3e de collèges d\'Aubervilliers,co-présentée par Marion et Baptiste avec des collégiens ? C\'est le mercredi 27 novembre de 9h30 à 10h30 !\r\n\r\nLe format lui ne change pas : les 2 classes présentent chacune 2 titres qu\'1 chroniqueuse et 1 chroniqueur de chaque classe viennent défendre. \r\n\r\nLa classe du collège Gabriel Péri défendra :\r\n- Saison des roses de Chloé Wary, aux Éditions FLBLB\r\n- Nako T1 de MAX, des Editions Michel Lafon \r\n\r\nLa classe du collège Denis Diderot \r\n- Raowl T.1 de Tebo, aux Éditionss Dupuis \r\n- Peau de mille bêtes de Stéphane Fert, des Éditions Delcourt\r\n\r\nL\'événement sera co-animé par Marion et Baptiste.', 'https://i.imgur.com/Q5yOfQU.png', 'SLPJ', '9h30'),
(52, '2019-12-02', '52', 'La dernière BDI de l\'année est une spéciale CUL ! \r\n\r\nAutobiographie intimiste, manga surprenant à caractère,  sociologique, récit de bythes & de légendes ou encore fable érotique : c\'est la première fois que la sélection se concentre sur ce thème aussi sulfureux qu\'universel. \r\n\r\n- Margot présentera 23 prostituées de Chester Brown aux Éditions Cornélius\r\n- Côme nous parlera de La virginité passée 30 an de Toshifumi Sakurai, Bargain Sakurai et Atsuhiko Nakamura édité chez Akata.\r\n- Raphaëlle défendra le dernier BDCUL : Déesse d\'Aude Picault chez Les Requins Marteaux Éditions\r\n- Léo présentera Otto ou l\'île miroir de Anne-Margot Ramstein des éditions 2024    \r\n\r\nPour cette édition présentée par Mathilde, la branlette intellectuelle sera de mise ! ', 'https://i.imgur.com/KLAmZxI.jpg', 'Lou Pascalou', '20h30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idUser`);

--
-- Indexes for table `auteurs`
--
ALTER TABLE `auteurs`
  ADD PRIMARY KEY (`idAuteur`);

--
-- Indexes for table `croquis`
--
ALTER TABLE `croquis`
  ADD PRIMARY KEY (`idCroquis`),
  ADD KEY `soirée_id_idx` (`soiree_id`) USING BTREE;

--
-- Indexes for table `dessinateurs`
--
ALTER TABLE `dessinateurs`
  ADD PRIMARY KEY (`idDessinateur`);

--
-- Indexes for table `editeurs`
--
ALTER TABLE `editeurs`
  ADD PRIMARY KEY (`idEditeur`);

--
-- Indexes for table `intervenants`
--
ALTER TABLE `intervenants`
  ADD PRIMARY KEY (`idIntervenant`);

--
-- Indexes for table `interventions`
--
ALTER TABLE `interventions`
  ADD PRIMARY KEY (`id_intervention`),
  ADD KEY `id_soiree` (`id_soiree`),
  ADD KEY `idintervenants` (`id_intervenant`);

--
-- Indexes for table `livres`
--
ALTER TABLE `livres`
  ADD PRIMARY KEY (`idLivre`),
  ADD UNIQUE KEY `intervenant_id2` (`intervenant_id2`),
  ADD KEY `id_soirees` (`soiree_id`),
  ADD KEY `id_intervenants` (`intervenant_id`),
  ADD KEY `id_editeur` (`edition`),
  ADD KEY `id_soirees2` (`soiree_id2`);

--
-- Indexes for table `livres_auteurs`
--
ALTER TABLE `livres_auteurs`
  ADD PRIMARY KEY (`idLivresAuteurs`),
  ADD KEY `id_auteur` (`id_auteur`),
  ADD KEY `id_dessinateur` (`id_dessinateur`),
  ADD KEY `id_livre` (`id_livre`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`idPhoto`),
  ADD KEY `soiree_id` (`soiree_id`);

--
-- Indexes for table `soirees`
--
ALTER TABLE `soirees`
  ADD PRIMARY KEY (`idSoiree`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idUser` smallint(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auteurs`
--
ALTER TABLE `auteurs`
  MODIFY `idAuteur` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `dessinateurs`
--
ALTER TABLE `dessinateurs`
  MODIFY `idDessinateur` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `editeurs`
--
ALTER TABLE `editeurs`
  MODIFY `idEditeur` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `intervenants`
--
ALTER TABLE `intervenants`
  MODIFY `idIntervenant` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `interventions`
--
ALTER TABLE `interventions`
  MODIFY `id_intervention` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `livres`
--
ALTER TABLE `livres`
  MODIFY `idLivre` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;

--
-- AUTO_INCREMENT for table `livres_auteurs`
--
ALTER TABLE `livres_auteurs`
  MODIFY `idLivresAuteurs` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=184;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `idPhoto` smallint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `soirees`
--
ALTER TABLE `soirees`
  MODIFY `idSoiree` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `croquis`
--
ALTER TABLE `croquis`
  ADD CONSTRAINT `soirée_id` FOREIGN KEY (`soiree_id`) REFERENCES `soirees` (`idSoiree`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `interventions`
--
ALTER TABLE `interventions`
  ADD CONSTRAINT `id_soiree` FOREIGN KEY (`id_soiree`) REFERENCES `soirees` (`idSoiree`),
  ADD CONSTRAINT `idintervenants` FOREIGN KEY (`id_intervenant`) REFERENCES `intervenants` (`idIntervenant`);

--
-- Constraints for table `livres`
--
ALTER TABLE `livres`
  ADD CONSTRAINT `id_editeur` FOREIGN KEY (`edition`) REFERENCES `editeurs` (`idEditeur`),
  ADD CONSTRAINT `id_intervenant2` FOREIGN KEY (`intervenant_id2`) REFERENCES `intervenants` (`idIntervenant`),
  ADD CONSTRAINT `id_intervenants` FOREIGN KEY (`intervenant_id`) REFERENCES `intervenants` (`idIntervenant`),
  ADD CONSTRAINT `id_soirees` FOREIGN KEY (`soiree_id`) REFERENCES `soirees` (`idSoiree`),
  ADD CONSTRAINT `id_soirees2` FOREIGN KEY (`soiree_id2`) REFERENCES `soirees` (`idSoiree`);

--
-- Constraints for table `livres_auteurs`
--
ALTER TABLE `livres_auteurs`
  ADD CONSTRAINT `id_auteur` FOREIGN KEY (`id_auteur`) REFERENCES `auteurs` (`idAuteur`),
  ADD CONSTRAINT `id_dessinateur` FOREIGN KEY (`id_dessinateur`) REFERENCES `dessinateurs` (`idDessinateur`),
  ADD CONSTRAINT `id_livre` FOREIGN KEY (`id_livre`) REFERENCES `livres` (`idLivre`);

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `soiree_id` FOREIGN KEY (`soiree_id`) REFERENCES `soirees` (`idSoiree`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
